
package modelo;

/**
 *
 * @author Andressa
 */
public class Mercado {
    private String produto;
    private int quantidade;

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    public double calcularTotal(){
        double total = 0;
        if(this.produto.equals("Bala")){
            total = this.quantidade * 0.10;
        }else if(this.produto.equals("Bombom")){
            total = this.quantidade * 0.60;
        }else if(this.produto.equals("Trakinas")){
            total = this.quantidade * 2.40;
        }else if(this.produto.equals("Ruffles")){
            total = this.quantidade * 2.20;
        }else if(this.produto.equals("Refri lata")){
            total = this.quantidade * 2.10;
        }
        return total;
    }
}
